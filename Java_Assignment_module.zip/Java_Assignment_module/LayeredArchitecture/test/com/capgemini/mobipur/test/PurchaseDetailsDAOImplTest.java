package com.capgemini.mobipur.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class PurchaseDetailsDAOImplTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public final void testInsertPurchase() {
		fail("Not yet implemented");
	}

}
