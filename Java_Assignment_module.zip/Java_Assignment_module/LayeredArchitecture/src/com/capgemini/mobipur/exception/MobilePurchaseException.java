package com.capgemini.mobipur.exception;

public class MobilePurchaseException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6234391941897466540L;

	public MobilePurchaseException(){
		super();
	}

	public MobilePurchaseException(String message) {
		super(message);
	}
	
	
	
}
