import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAccessor;
import java.util.Scanner;


public class ConvertDate {

	public static void main(String[] args) {
	DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
	
	Scanner sc = new Scanner(System.in);
	
	String strDate = null;
	
	System.out.println("Enter Date: ");
	strDate = sc.nextLine();
	
	TemporalAccessor ta = dtf.parse(strDate);
	
	LocalDate localDate = LocalDate.from(ta);
	
	java.sql.Date translatedDate = java.sql.Date.valueOf(localDate);
	
	System.out.println(translatedDate);
	
	sc.close();

	}

}
